a = int(input("Enter value of a: "))
b = int(input("Enter value of b: "))
ans= a+b
print("Answer is: ",ans)