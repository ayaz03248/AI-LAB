x = input("Enter Any type of String......\n");
s = len(x.split());
print("Total Words :",s)