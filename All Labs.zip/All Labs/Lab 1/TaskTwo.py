#In this Program  Simply Add Two Numbers...
x= int(input("Enter the first Number...."))
y = int(input("Enter the Second Number..."))
c = x+y;
print(c)