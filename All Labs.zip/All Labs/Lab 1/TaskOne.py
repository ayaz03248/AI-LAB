print("Name:\t\t\tAyazQureshi. ");
print("Qualification:\tUndergraduate");
print("Email:\t\t\tayaz03248@gmail.com");