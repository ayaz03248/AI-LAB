x =input("Enter Any Number to check whether is Even Or Odd\n");
if(x%2 == 0):
 print("Even");

else:
    print("Odd");
