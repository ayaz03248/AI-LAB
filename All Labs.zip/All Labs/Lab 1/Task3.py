a = int(input("Enter a Number: "))

if(a%2==1):
     print("Odd")
else:
    print("Even")

