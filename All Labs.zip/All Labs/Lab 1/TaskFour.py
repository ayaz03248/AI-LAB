x= int(input("Enter any Number...\n"))
if(x>=1 and x<=3):
    print("Winter Season")
elif(x>=4 and x<=6):
    print("Spring Season")
elif(x>=7 and x<=9):
    print("Summer Season")
elif(x>=10 and x<=12):
    print("Autum Season")
else:
    print("Wrong Input")