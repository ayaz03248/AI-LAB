import math as m
import numpy as np
import matplotlib.pyplot as plt
X = np.linspace(1,2,100 )
Y = np.sin(X)
print(X)
print(Y)
plt.scatter(X,Y)
plt.show()


