from django.apps import AppConfig


class AdulcensusincomeConfig(AppConfig):
    name = 'AdulCensusIncome'
